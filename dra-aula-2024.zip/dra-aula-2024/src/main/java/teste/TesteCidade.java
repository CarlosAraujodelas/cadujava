package teste;

import modelo.Cidade;
import modelo.Pessoa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.List;

public class TesteCidade {

   private static void persistir(){
        EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("Banco01PU");
        EntityManager entityManager = fabrica.createEntityManager();

        Cidade c = new Cidade("1234567","Moçoró","MA");
        entityManager.getTransaction().begin();

        entityManager.persist(c);

        entityManager.getTransaction().commit();

        entityManager.close();

        fabrica.close();
    }
    private static void deletar(){
        EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("Banco01PU");

        EntityManager entityManager = fabrica.createEntityManager();

        entityManager.getTransaction().begin();
        Cidade cidade = entityManager.find(Cidade.class, "1234567");

        entityManager.remove(cidade);

        entityManager.getTransaction().commit();
        entityManager.close();
        fabrica.close();
    }

    private static void atualizar(){
        EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("Banco01PU");

        EntityManager entityManager = fabrica.createEntityManager();

        entityManager.getTransaction().begin();
        Cidade cidade = entityManager.find(Cidade.class, 1l);

        cidade.setNome("Xique-Xique");

        entityManager.getTransaction().commit();
        entityManager.close();
        fabrica.close();
    }

    private static void mesclar(){
        EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("Banco01PU");

        EntityManager entityManager = fabrica.createEntityManager();

        Cidade cidade = new Cidade();
        cidade.setCidade_id(1l);
        cidade.setNome("Melgaço");

        entityManager.getTransaction().begin();

        entityManager.merge(cidade);

        entityManager.getTransaction().commit();
        entityManager.close();
        fabrica.close();
    }


    private static void listar(){
        EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("Banco01PU");

        EntityManager entityManager = fabrica.createEntityManager();

        String consulta = "select c from Cidade c";

        Query query = entityManager.createQuery(consulta);

        List<Cidade> cidades = query.getResultList();

        for(Cidade c: cidades){
            System.out.println(c.getNome());
            System.out.println(c.getIbge());
            System.out.println(c.getEstado());
            System.out.println("****************");
        }

        entityManager.close();

        fabrica.close();
    }

    public void main (String[] args){
        //persistir();
        //deletar();
        //listar();
        //mesclar();
    }

}
