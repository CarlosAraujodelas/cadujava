package teste;

import dao.PessoaDao;
import modelo.Cidade;
import modelo.Pessoa;
import util.ConexaoUtil;

import javax.persistence.EntityManager;

public class TestaPessoaComCidade {
    public static void inserir(){
        EntityManager entityManager =  ConexaoUtil.getEntityManager();
        Pessoa pessoa = new Pessoa("06512581202", "Marcela", "8654-3214", "marcela@gmail.com");
        PessoaDao pessoaDao = new PessoaDao();
        Cidade cidade = new Cidade();

        pessoaDao.setEntityManager(entityManager);

        cidade.setNome("Manaus");
        cidade.setEstado("Am");
        cidade.setIbge("25345");
        pessoa.setCidade(cidade);

        entityManager.persist(cidade);

        pessoaDao.inserirPessoa(pessoa);
        entityManager.close();
    }

    public static void inserirNovaPessoaNovaCidade(Pessoa p, Cidade c){
        EntityManager entityManager =  ConexaoUtil.getEntityManager();
        PessoaDao pessoaDao = new PessoaDao();
        Cidade cidade = new Cidade();
        pessoaDao.setEntityManager(entityManager);
        entityManager.persist(c);
        p.setCidade(c);
        pessoaDao.inserirPessoa(p);
        entityManager.close();
    }

    public static void inserirNovaPessoaCidadeExistente(){
        EntityManager entityManager =  ConexaoUtil.getEntityManager();
        Pessoa pessoa = new Pessoa("06512581202", "Marcela", "8654-3214", "marcela@gmail.com");
        PessoaDao pessoaDao = new PessoaDao();
        Cidade cidade = new Cidade();

        cidade = entityManager.find(Cidade.class, 2L);
        pessoaDao.setEntityManager(entityManager);

        cidade.setNome("Manaus");
        cidade.setEstado("Am");
        cidade.setIbge("25345");
        pessoa.setCidade(cidade);

        entityManager.persist(cidade);

        pessoaDao.inserirPessoa(pessoa);
        entityManager.close();
    }

    public static void main(String[] args){
        inserir();
        ConexaoUtil.fecharFabrica();
    }
}
