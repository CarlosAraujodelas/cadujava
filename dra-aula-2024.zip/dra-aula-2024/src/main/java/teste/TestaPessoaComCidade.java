package teste;

import dao.PessoaDao;
import modelo.Cidade;
import modelo.Pessoa;
import util.ConexaoUtil;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestaPessoaComCidade {
    public static void inserir(){
        EntityManager entityManager =  ConexaoUtil.getEntityManager();
        Pessoa pessoa = new Pessoa("06512581202", "Marcela", "8654-3214", "marcela@gmail.com");
        PessoaDao pessoaDao = new PessoaDao();
        Cidade cidade = new Cidade();

        pessoaDao.setEntityManager(entityManager);

        cidade.setNome("Manaus");
        cidade.setEstado("Am");
        cidade.setIbge("25345");
        pessoa.setCidade(cidade);

        entityManager.persist(cidade);

        pessoaDao.inserirPessoa(pessoa);
        entityManager.close();
    }

    public static void inserirNovaPessoaNovaCidade(Pessoa p, Cidade c){
        EntityManager entityManager =  ConexaoUtil.getEntityManager();
        PessoaDao pessoaDao = new PessoaDao();
        Cidade cidade = new Cidade();
        pessoaDao.setEntityManager(entityManager);
        entityManager.persist(c);
        p.setCidade(c);
        pessoaDao.inserirPessoa(p);
        entityManager.close();
    }


    private static void inserirNovaPessoaComCidadeJaSalva() {

        EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("Banco01PU");

        EntityManager entityManager = fabrica.createEntityManager();


        Pessoa pessoa = new Pessoa("12345678904","Rogerio2","3234-5678","rogerio4@email.com");

        Cidade cidade = entityManager.find(Cidade.class,3L);
        pessoa.setCidade(cidade);

        entityManager.getTransaction().begin();

        entityManager.persist(pessoa);

        entityManager.getTransaction().commit();

        entityManager.close();

        fabrica.close();

    }

    public void main(String[] args){
        inserir();
        ConexaoUtil.fecharFabrica();
    }
}
