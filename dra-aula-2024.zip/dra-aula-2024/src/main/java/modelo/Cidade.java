package modelo;

import javax.persistence.*;

@Entity
public class Cidade {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cidade_id;

    @Column(nullable = false, unique = true, length = 7)
    private String ibge;
    @Column(nullable = false)
    private String nome;
    @Column(nullable = false)
    private String estado;

    public Cidade() {}

    public Cidade(String ibge, String nome, String estado) {
        this.ibge = ibge;
        this.nome = nome;
        this.estado = estado;
    }

    public String getIbge() {
        return ibge;
    }

    public void setIbge(String ibge) {
        this.ibge = ibge;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Long getCidade_id() {
        return cidade_id;
    }

    public void setCidade_id(Long cidade_id) {
        this.cidade_id = cidade_id;
    }
}
