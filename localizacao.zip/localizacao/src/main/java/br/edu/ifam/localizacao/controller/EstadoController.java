package br.edu.ifam.localizacao.controller;

import br.edu.ifam.localizacao.dto.CidadeOutputDTO;
import br.edu.ifam.localizacao.dto.EstadoOutputDTO;
import br.edu.ifam.localizacao.model.Cidade;
import br.edu.ifam.localizacao.model.Estado;
import br.edu.ifam.localizacao.repository.EstadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api2/estado")
public class EstadoController {

    @Autowired
    private EstadoRepository estadoRepository;

    @GetMapping
    public ResponseEntity<List<Estado>> list(){
        List<Estado> estados = estadoRepository.findAll();
        if(estados.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }else{
            return new ResponseEntity<>(estados, HttpStatus.OK);
        }
    }

    @PostMapping (consumes= MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Estado> create(@RequestBody Estado estado){
        try{
            Estado estadoCriado = estadoRepository.save(estado);
            return new ResponseEntity<>(estadoCriado, HttpStatus.OK);
        }catch(Exception e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value ="/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<EstadoOutputDTO> getByID(@PathVariable Long id){
        Optional<Estado> estado = estadoRepository.findById(id);
        if(estado.isPresent()){
            EstadoOutputDTO estadoOutputDTO = new EstadoOutputDTO(estado.get());
            return new ResponseEntity<>(estadoOutputDTO, HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping(value ="/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        Optional<Estado> estado = estadoRepository.findById(id);
        if(estado.isPresent()){
            estadoRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping(consumes= MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, value ="/{id}")
    public ResponseEntity<EstadoOutputDTO> alter(@RequestBody Estado estado, @PathVariable Long id){
        Optional<Estado> e = estadoRepository.findById(id);
        if(e.isPresent()){
            Estado e1 = e.get();
            e1.setNome(estado.getNome());
            e1.setIbge(estado.getIbge());
            Estado estadoBD = estadoRepository.save(e1);
            return new ResponseEntity<>(new EstadoOutputDTO(estadoBD),HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


}
