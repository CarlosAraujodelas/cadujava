package br.edu.ifam.localizacao.service;

import br.edu.ifam.localizacao.dto.LogradouroInputDTO;
import br.edu.ifam.localizacao.dto.LogradouroOutputDTO;
import br.edu.ifam.localizacao.model.Logradouro;
import br.edu.ifam.localizacao.repository.CidadeRepository;
import br.edu.ifam.localizacao.repository.LogradouroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class LogradouroService {

    @Autowired
    private LogradouroRepository logradouroRepository;

    @Autowired
    private CidadeRepository cidadeRepository;

    public List<LogradouroOutputDTO> list() {
        List<Logradouro> logradouros = logradouroRepository.findAll();
        List<LogradouroOutputDTO> result = new ArrayList<>();

        for (Logradouro logradouro : logradouros) {
            result.add(new LogradouroOutputDTO(logradouro));
        }
        return result;
    }

    public LogradouroOutputDTO create(LogradouroInputDTO logradouroInputDTO) {
        try {
            Logradouro logradouro = logradouroInputDTO.build(cidadeRepository);
            return new LogradouroOutputDTO(logradouroRepository.save(logradouro));
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    public LogradouroOutputDTO getById(Long id) {
        try {
            return new LogradouroOutputDTO(logradouroRepository.findById(id).orElseThrow());
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    public Boolean deleteById(Long id) {
        Optional<Logradouro> logradouro = logradouroRepository.findById(id);
        if (logradouro.isPresent()) {
            logradouroRepository.deleteById(id);
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }
    }

    public LogradouroOutputDTO alter(Logradouro logradouro, Long id) {
        Optional<Logradouro> existing = logradouroRepository.findById(id);
        if (existing.isPresent()) {
            Logradouro updated = existing.get();
            updated.setNome(logradouro.getNome());
            updated.setCep(logradouro.getCep());
            updated.setCidade(logradouro.getCidade());
            return new LogradouroOutputDTO(logradouroRepository.save(updated));
        } else {
            throw new RuntimeException("Logradouro não encontrado.");
        }
    }


}
