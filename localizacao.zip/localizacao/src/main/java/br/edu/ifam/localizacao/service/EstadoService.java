package br.edu.ifam.localizacao.service;

import br.edu.ifam.localizacao.dto.EstadoInputDTO;
import br.edu.ifam.localizacao.dto.EstadoOutputDTO;
import br.edu.ifam.localizacao.model.Estado;
import br.edu.ifam.localizacao.repository.EstadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EstadoService {

    @Autowired
    EstadoRepository estadoRepository;

    public List<EstadoOutputDTO> list(){
        List<Estado> estados = estadoRepository.findAll();
        List<EstadoOutputDTO> estados1 = new ArrayList<>();

        for(Estado estado:estados){
            estados1.add(new EstadoOutputDTO(estado));
        }
        return estados1;
    }

    public EstadoOutputDTO create(EstadoInputDTO estadoInputDTO){
        try{
            Estado estado = estadoInputDTO.build();
            return  new EstadoOutputDTO(estadoRepository.save(estado));
        }catch(Exception ex){
            throw new RuntimeException(ex);
        }
    }

    public EstadoOutputDTO getById(Long id) {
        try{
            EstadoOutputDTO e1 = new EstadoOutputDTO(estadoRepository.findById(id).get());
            return e1;
        }catch(Exception ex){
            throw new RuntimeException(ex);
        }
    }

    public Boolean deleteById(Long id){
        Optional<Estado> estado = estadoRepository.findById(id);
        if(estado.isPresent()){
            estadoRepository.deleteById(id);
            return Boolean.TRUE;
        }else{
            return Boolean.TRUE;
        }
    }

    public EstadoOutputDTO alter(Estado estado, Long id) {
        Optional<Estado> e = estadoRepository.findById(id);
        if (e.isPresent()) {
            Estado e1 = e.get();
            e1.setNome(estado.getNome());
            e1.setIbge(estado.getIbge());
            return new EstadoOutputDTO(estadoRepository.save(e1));
        } else {
            return new EstadoOutputDTO(e.get());
        }
    }

}
