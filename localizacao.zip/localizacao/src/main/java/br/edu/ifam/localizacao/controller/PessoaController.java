package br.edu.ifam.localizacao.controller;

import br.edu.ifam.localizacao.dto.CidadeOutputDTO;
import br.edu.ifam.localizacao.dto.PessoaOutputDTO;
import br.edu.ifam.localizacao.model.Cidade;
import br.edu.ifam.localizacao.model.Pessoa;
import br.edu.ifam.localizacao.repository.PessoaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api2/pessoa")
public class PessoaController {
    @Autowired
    PessoaRepository pessoaRepository;

    @GetMapping
    public ResponseEntity<List<PessoaOutputDTO>> list(){
        List<PessoaOutputDTO> pessoas = new ArrayList<>();
        List<Pessoa> pessoas1 =pessoaRepository.findAll();
        if(pessoas1.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }else{
            for (Pessoa p:pessoas1){
                pessoas.add(new PessoaOutputDTO(p));
            }
            return new ResponseEntity<>(pessoas, HttpStatus.OK);
        }
    }

    @GetMapping(value ="/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PessoaOutputDTO> getByID(@PathVariable Long id){
        Optional<Pessoa> pessoa = pessoaRepository.findById(id);
        if(pessoa.isPresent()){
            return new ResponseEntity<>(new PessoaOutputDTO(pessoa.get()), HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping(consumes= MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PessoaOutputDTO> create(@RequestBody Pessoa pessoa){
        try{
            Pessoa pessoaCriada = pessoaRepository.save(pessoa);
            return new ResponseEntity<>(new PessoaOutputDTO(pessoa), HttpStatus.OK);
        }catch(Exception e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping(value ="/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        Optional<Pessoa> pessoa = pessoaRepository.findById(id);
        if(pessoa.isPresent()){
            pessoaRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping(consumes= MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, value ="/{id}")
    public ResponseEntity<PessoaOutputDTO> alter(@RequestBody Pessoa pessoa,@PathVariable Long id){
        Optional<Pessoa> p = pessoaRepository.findById(id);
        if(p.isPresent()){
            Pessoa p1 = p.get();
            p1.setNome(pessoa.getNome());
            p1.setCpf(pessoa.getCpf());
            p1.setTelefone(pessoa.getTelefone());
            p1.setEmail(pessoa.getEmail());
            p1.setNumeroEndereco(pessoa.getNumeroEndereco());
            p1.setComplementoEndereco(pessoa.getComplementoEndereco());
            p1.setLogradouro(pessoa.getLogradouro());
            Pessoa pessoBD = pessoaRepository.save(p1);
            return new ResponseEntity<>(new PessoaOutputDTO(pessoBD),HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
