package br.edu.ifam.localizacao.dto;

import br.edu.ifam.localizacao.model.Estado;

public class EstadoInputDTO {
    private String nome;
    private String ibge;

    public EstadoInputDTO() {}

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIbge() {
        return ibge;
    }

    public void setIbge(String ibge) {
        this.ibge = ibge;
    }

    public Estado build(){
        Estado estado = new Estado();
        estado.setNome(this.getNome());
        estado.setIbge(this.getIbge());
        return estado;
    }

}
