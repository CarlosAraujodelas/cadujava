package br.edu.ifam.localizacao.dto;

import br.edu.ifam.localizacao.model.Cidade;
import br.edu.ifam.localizacao.repository.EstadoRepository;

public class CidadeInputDTO {
    private String ibge;
    private String nome;
    private String estado;

    public CidadeInputDTO() {}

    public CidadeInputDTO(String ibge, String nome, String estado) {
        this.ibge = ibge;
        this.nome = nome;
        this.estado = estado;
    }

    public String getIbge() {
        return ibge;
    }

    public void setIbge(String ibge) {
        this.ibge = ibge;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Cidade build(EstadoRepository estadoRepository){
        Cidade cidade = new Cidade();
        cidade.setIbge(this.ibge);
        cidade.setNome(this.nome);
        cidade.setEstado(estadoRepository.fyndByNome(this.estado));
        return cidade;
    }

}
