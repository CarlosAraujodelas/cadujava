package br.edu.ifam.localizacao.controller;

import br.edu.ifam.localizacao.dto.CidadeInputDTO;
import br.edu.ifam.localizacao.dto.CidadeOutputDTO;
import br.edu.ifam.localizacao.dto.EstadoOutputDTO;
import br.edu.ifam.localizacao.model.Cidade;
import br.edu.ifam.localizacao.model.Estado;
import br.edu.ifam.localizacao.model.Logradouro;
import br.edu.ifam.localizacao.repository.CidadeRepository;
import br.edu.ifam.localizacao.repository.EstadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api2/cidade")
public class CidadeController {

    @Autowired
    CidadeRepository cidadeRepository;

    @Autowired
    EstadoRepository estadoRepository;

    @GetMapping
    public ResponseEntity<List<CidadeOutputDTO>> list(){
        List<CidadeOutputDTO> cidades = new ArrayList<>();
        List<Cidade> cidades1 = cidadeRepository.findAll();
        if(cidades1.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }else{
            for (Cidade c:cidades1){
                cidades.add(new CidadeOutputDTO(c));
            }
            return new ResponseEntity<>(cidades, HttpStatus.OK);
        }
    }

    @GetMapping(value ="/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CidadeOutputDTO> getByID(@PathVariable Long id){
        Optional<Cidade> cidade = cidadeRepository.findById(id);
        if(cidade.isPresent()){
            return new ResponseEntity<>(new CidadeOutputDTO(cidade.get()), HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping(consumes= MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CidadeOutputDTO> create(@RequestBody CidadeInputDTO cidadeInputDTO){
        try{
            Cidade cidadeCriada = cidadeRepository.save(cidadeInputDTO.build(estadoRepository));
            return new ResponseEntity<>(new CidadeOutputDTO(cidadeCriada), HttpStatus.OK);
        }catch(Exception e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping(value ="/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        Optional<Cidade> cidade = cidadeRepository.findById(id);
        if(cidade.isPresent()){
            cidadeRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping(consumes= MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, value ="/{id}")
    public ResponseEntity<CidadeOutputDTO> alter(@RequestBody CidadeInputDTO cidadeInputDTO,@PathVariable Long id){
        Optional<Cidade> c = cidadeRepository.findById(id);
        Cidade cidade = cidadeInputDTO.build(estadoRepository);
        if(c.isPresent()){
            Cidade c1 = c.get();
            c1.setNome(cidade.getNome());
            c1.setIbge(cidade.getIbge());
            c1.setEstado(cidade.getEstado());
            Cidade cidadeBD = cidadeRepository.save(c1);
            return new ResponseEntity<>(new CidadeOutputDTO(cidadeBD),HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
