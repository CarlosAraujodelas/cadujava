package br.edu.ifam.localizacao.dto;

import br.edu.ifam.localizacao.model.Pessoa;

public class PessoaOutputDTO {
    private long id;
    private String nome;
    private String cpf;
    private String telefone;
    private String email;
    private String numeroEndereco;
    private String complementoEndereco;
    private String logradouro;

    public PessoaOutputDTO() {}

    public PessoaOutputDTO(Pessoa pessoa) {
        this.id = pessoa.getId();
        this.nome = pessoa.getNome();
        this.cpf = pessoa.getCpf();
        this.telefone = pessoa.getTelefone();
        this.email = pessoa.getEmail();
        this.numeroEndereco = pessoa.getNumeroEndereco();
        this.complementoEndereco = pessoa.getComplementoEndereco();
        this.logradouro = pessoa.getLogradouro().getNome();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNumeroEndereco() {
        return numeroEndereco;
    }

    public void setNumeroEndereco(String numeroEndereco) {
        this.numeroEndereco = numeroEndereco;
    }

    public String getComplementoEndereco() {
        return complementoEndereco;
    }

    public void setComplementoEndereco(String complementoEndereco) {
        this.complementoEndereco = complementoEndereco;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }
}
