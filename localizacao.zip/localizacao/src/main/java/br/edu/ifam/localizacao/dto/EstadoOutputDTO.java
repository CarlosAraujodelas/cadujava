package br.edu.ifam.localizacao.dto;

import br.edu.ifam.localizacao.model.Estado;

public class EstadoOutputDTO {
    private String nome;
    private String ibge;

    public EstadoOutputDTO() {}

    public EstadoOutputDTO(Estado estado) {
        this.nome = estado.getNome();
        this.ibge = estado.getIbge();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIbge() {
        return ibge;
    }

    public void setIbge(String ibge) {
        this.ibge = ibge;
    }

}
