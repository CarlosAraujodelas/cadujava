package br.edu.ifam.localizacao.repository;

import br.edu.ifam.localizacao.model.Logradouro;
import br.edu.ifam.localizacao.model.Pessoa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PessoaRepository extends JpaRepository<Pessoa,Long> {
}
