package br.edu.ifam.localizacao.service;

import br.edu.ifam.localizacao.dto.PessoaInputDTO;
import br.edu.ifam.localizacao.dto.PessoaOutputDTO;
import br.edu.ifam.localizacao.model.Pessoa;
import br.edu.ifam.localizacao.repository.LogradouroRepository;
import br.edu.ifam.localizacao.repository.PessoaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class PessoaService {

    @Autowired
    PessoaRepository pessoaRepository;

    @Autowired
    LogradouroRepository logradouroRepository;

    public List<PessoaOutputDTO> list() {
        List<Pessoa> pessoas = pessoaRepository.findAll();
        List<PessoaOutputDTO> pessoasDTO = new ArrayList<>();

        for (Pessoa pessoa : pessoas) {
            pessoasDTO.add(new PessoaOutputDTO(pessoa));
        }

        return pessoasDTO;
    }

    public PessoaOutputDTO create(PessoaInputDTO pessoaInputDTO) {
        try {
            Pessoa pessoa = pessoaInputDTO.build(logradouroRepository);
            return new PessoaOutputDTO(pessoaRepository.save(pessoa));
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    public PessoaOutputDTO getById(Long id) {
        try {
            return new PessoaOutputDTO(pessoaRepository.findById(id).get());
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    public Boolean deleteById(Long id) {
        Optional<Pessoa> pessoa = pessoaRepository.findById(id);
        if (pessoa.isPresent()) {
            pessoaRepository.deleteById(id);
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }
    }

    public PessoaOutputDTO alter(Pessoa pessoa, Long id) {
        Optional<Pessoa> existingPessoa = pessoaRepository.findById(id);
        if (existingPessoa.isPresent()) {
            Pessoa updatedPessoa = existingPessoa.get();
            updatedPessoa.setNome(pessoa.getNome());
            updatedPessoa.setCpf(pessoa.getCpf());
            updatedPessoa.setEmail(pessoa.getEmail());
            updatedPessoa.setTelefone(pessoa.getTelefone());
            updatedPessoa.setNumeroEndereco(pessoa.getNumeroEndereco());
            updatedPessoa.setComplementoEndereco(pessoa.getComplementoEndereco());
            updatedPessoa.setLogradouro(pessoa.getLogradouro());
            return new PessoaOutputDTO(pessoaRepository.save(updatedPessoa));
        } else {
            return new PessoaOutputDTO(existingPessoa.get());
        }
    }
}
