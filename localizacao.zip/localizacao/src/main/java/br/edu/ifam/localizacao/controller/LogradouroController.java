package br.edu.ifam.localizacao.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class LogradouroController {
}
