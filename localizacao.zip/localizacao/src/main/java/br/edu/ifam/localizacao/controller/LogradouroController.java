package br.edu.ifam.localizacao.controller;

import br.edu.ifam.localizacao.dto.LogradouroInputDTO;
import br.edu.ifam.localizacao.dto.LogradouroOutputDTO;
import br.edu.ifam.localizacao.model.Logradouro;
import br.edu.ifam.localizacao.repository.CidadeRepository;
import br.edu.ifam.localizacao.repository.LogradouroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api2/logradouro")
public class LogradouroController {
    @Autowired
    LogradouroRepository logradouroRepository;

    @Autowired
    CidadeRepository cidadeRepository;

    @GetMapping
    public ResponseEntity<List<LogradouroOutputDTO>> list(){
        List<LogradouroOutputDTO> logradouros = new ArrayList<>();
        List<Logradouro> logradouros1 = logradouroRepository.findAll();
        if(logradouros1.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }else{
            for (Logradouro l:logradouros1){
                logradouros.add(new LogradouroOutputDTO(l));
            }
            return new ResponseEntity<>(logradouros, HttpStatus.OK);
        }
    }

    @GetMapping(value ="/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<LogradouroOutputDTO> getByID(@PathVariable Long id){
        Optional<Logradouro> logradouro = logradouroRepository.findById(id);
        if(logradouro.isPresent()){
            return new ResponseEntity<>(new LogradouroOutputDTO(logradouro.get()), HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping(consumes= MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<LogradouroOutputDTO> create(@RequestBody LogradouroInputDTO logradouroInputDTO){
        try{
            Logradouro logBD = logradouroRepository.save(logradouroInputDTO.build(cidadeRepository));
            return new ResponseEntity<>(new LogradouroOutputDTO(logBD), HttpStatus.OK);
        }catch(Exception e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping(value ="/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        Optional<Logradouro> logradouro = logradouroRepository.findById(id);
        if(logradouro.isPresent()){
            logradouroRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping(consumes= MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, value ="/{id}")
    public ResponseEntity<LogradouroOutputDTO> alter(@RequestBody LogradouroInputDTO logradouroInputDTO, @PathVariable Long id){
        Optional<Logradouro> l = logradouroRepository.findById(id);
        Logradouro logradouro = logradouroInputDTO.build(cidadeRepository);
        if(l.isPresent()){
            Logradouro l1 = l.get();
            l1.setNome(logradouro.getNome());
            l1.setCep(logradouro.getCep());
            l1.setCidade(logradouro.getCidade());
            Logradouro logBD= logradouroRepository.save(l1);
            return new ResponseEntity<>(new LogradouroOutputDTO(logBD),HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
