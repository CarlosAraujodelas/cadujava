package br.edu.ifam.localizacao.controller;

import br.edu.ifam.localizacao.dto.CidadeOutputDTO;
import br.edu.ifam.localizacao.dto.LogradouroOutputDto;
import br.edu.ifam.localizacao.model.Cidade;
import br.edu.ifam.localizacao.model.Estado;
import br.edu.ifam.localizacao.model.Logradouro;
import br.edu.ifam.localizacao.repository.CidadeRepository;
import br.edu.ifam.localizacao.repository.LogradouroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api2/logradouro")
public class LogradouroController {
    @Autowired
    LogradouroRepository logradouroRepository;

    @GetMapping
    public ResponseEntity<List<LogradouroOutputDto>> list(){
        List<LogradouroOutputDto> logradouros = new ArrayList<>();
        List<Logradouro> logradouros1 = logradouroRepository.findAll();
        if(logradouros1.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }else{
            for (Logradouro l:logradouros1){
                logradouros.add(new LogradouroOutputDto(l));
            }
            return new ResponseEntity<>(logradouros, HttpStatus.OK);
        }
    }

    @GetMapping(value ="/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<LogradouroOutputDto> getByID(@PathVariable Long id){
        Optional<Logradouro> logradouro = logradouroRepository.findById(id);
        if(logradouro.isPresent()){
            return new ResponseEntity<>(new LogradouroOutputDto(logradouro.get()), HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping(consumes= MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<LogradouroOutputDto> create(@RequestBody Logradouro logradouro){
        try{
            Logradouro logBD = logradouroRepository.save(logradouro);
            return new ResponseEntity<>(new LogradouroOutputDto(logBD), HttpStatus.OK);
        }catch(Exception e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping(value ="/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        Optional<Logradouro> logradouro = logradouroRepository.findById(id);
        if(logradouro.isPresent()){
            logradouroRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping(consumes= MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, value ="/{id}")
    public ResponseEntity<LogradouroOutputDto> alter(@RequestBody Logradouro logradouro,@PathVariable Long id){
        Optional<Logradouro> l = logradouroRepository.findById(id);
        if(l.isPresent()){
            Logradouro l1 = l.get();
            l1.setNome(logradouro.getNome());
            l1.setCep(logradouro.getCep());
            l1.setCidade(logradouro.getCidade());
            Logradouro logBD= logradouroRepository.save(l1);
            return new ResponseEntity<>(new LogradouroOutputDto(logBD),HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
