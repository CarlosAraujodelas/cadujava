package br.edu.ifam.localizacao.dto;

import br.edu.ifam.localizacao.model.Logradouro;
import br.edu.ifam.localizacao.repository.CidadeRepository;

public class LogradouroInputDTO {
    private String nome;
    private String cep;
    private String ibge;

    public LogradouroInputDTO() {}

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getIbge() {
        return ibge;
    }

    public void setIbge(String ibge) {
        this.ibge = ibge;
    }

    public Logradouro build(CidadeRepository cidadeRepository){
        Logradouro logradouro = new Logradouro();
        logradouro.setCep(this.cep);
        logradouro.setNome(this.nome);
        logradouro.setCidade(cidadeRepository.fyndByIbge(this.ibge));
        return logradouro;
    }

}
