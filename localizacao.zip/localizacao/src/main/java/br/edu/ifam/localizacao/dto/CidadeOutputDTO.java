package br.edu.ifam.localizacao.dto;

import br.edu.ifam.localizacao.model.Cidade;

public class CidadeOutputDTO {
    private long id;
    private String nome;
    private String ibge;
    private String estado;

    public CidadeOutputDTO() {
    }

    public CidadeOutputDTO(Cidade cidade) {
        this.id = cidade.getId();
        this.nome = cidade.getNome();
        this.ibge = cidade.getNome();
        this.estado = cidade.getEstado().getNome();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIbge() {
        return ibge;
    }

    public void setIbge(String ibge) {
        this.ibge = ibge;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
