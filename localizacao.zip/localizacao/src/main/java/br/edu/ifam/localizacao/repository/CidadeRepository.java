package br.edu.ifam.localizacao.repository;

import br.edu.ifam.localizacao.model.Cidade;
import br.edu.ifam.localizacao.model.Estado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CidadeRepository extends JpaRepository<Cidade,Long> {

    @Query("select c from Cidade c where c.ibge = :parIbge")
    Cidade fyndByIbge(@Param("parIbge") String ibge);

}
