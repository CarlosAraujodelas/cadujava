package br.edu.ifam.localizacao.repository;

import br.edu.ifam.localizacao.model.Estado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface EstadoRepository extends JpaRepository<Estado,Long> {

    @Query("select e from Estado e where e.nome = :parNome")
    Estado fyndByNome(@Param("parNome") String nome);

}
