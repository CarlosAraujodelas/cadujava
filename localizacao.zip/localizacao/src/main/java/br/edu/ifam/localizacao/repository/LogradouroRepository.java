package br.edu.ifam.localizacao.repository;

import br.edu.ifam.localizacao.model.Logradouro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface LogradouroRepository extends JpaRepository<Logradouro,Long> {

    @Query("select l from Logradouro l where l.cep = :parCep")
    Logradouro fyndByCep(@Param("parCep") String cep);
}
