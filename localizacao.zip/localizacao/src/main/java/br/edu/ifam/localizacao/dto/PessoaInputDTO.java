package br.edu.ifam.localizacao.dto;

import br.edu.ifam.localizacao.model.Pessoa;
import br.edu.ifam.localizacao.repository.LogradouroRepository;

public class PessoaInputDTO {
    private String nome;
    private String cpf;
    private String telefone;
    private String email;
    private String numeroEndereco;
    private String complementoEndereco;
    private String cep;

    public PessoaInputDTO() {}

    public Pessoa build(LogradouroRepository logradouroRepository){
        Pessoa pessoa = new Pessoa();
        pessoa.setCpf(this.cpf);
        pessoa.setNome(this.nome);
        pessoa.setEmail(this.email);
        pessoa.setTelefone(this.telefone);
        pessoa.setNumeroEndereco(this.numeroEndereco);
        pessoa.setComplementoEndereco(this.complementoEndereco);
        pessoa.setLogradouro(logradouroRepository.fyndByCep(this.cep));
        return pessoa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNumeroEndereco() {
        return numeroEndereco;
    }

    public void setNumeroEndereco(String numeroEndereco) {
        this.numeroEndereco = numeroEndereco;
    }

    public String getComplementoEndereco() {
        return complementoEndereco;
    }

    public void setComplementoEndereco(String complementoEndereco) {
        this.complementoEndereco = complementoEndereco;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }
}
