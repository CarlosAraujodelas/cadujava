package br.edu.ifam.localizacao.service;

public class CidadeService {
}
