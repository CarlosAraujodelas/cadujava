package br.edu.ifam.localizacao.service;

import br.edu.ifam.localizacao.dto.CidadeInputDTO;
import br.edu.ifam.localizacao.dto.CidadeOutputDTO;
import br.edu.ifam.localizacao.dto.EstadoInputDTO;
import br.edu.ifam.localizacao.dto.EstadoOutputDTO;
import br.edu.ifam.localizacao.model.Cidade;
import br.edu.ifam.localizacao.model.Estado;
import br.edu.ifam.localizacao.repository.CidadeRepository;
import br.edu.ifam.localizacao.repository.EstadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CidadeService {

    @Autowired
    CidadeRepository cidadeRepository;

    @Autowired
    EstadoRepository estadoRepository;

    public List<CidadeOutputDTO> list(){
        List<Cidade> cidades = cidadeRepository.findAll();
        List<CidadeOutputDTO> cidades1 = new ArrayList<>();

        for(Cidade cidade:cidades){
            cidades1.add(new CidadeOutputDTO(cidade));
        }
        return cidades1;
    }

    public CidadeOutputDTO create(CidadeInputDTO cidadeInputDTO){
        try{
            Cidade cidade = cidadeInputDTO.build(estadoRepository);
            return  new CidadeOutputDTO(cidadeRepository.save(cidade));
        }catch(Exception ex){
            throw new RuntimeException(ex);
        }
    }

    public CidadeOutputDTO getById(Long id) {
        try{
            return new CidadeOutputDTO(cidadeRepository.findById(id).get());
        }catch(Exception ex){
            throw new RuntimeException(ex);
        }
    }

    public Boolean deleteById(Long id) {
        Optional<Cidade> cidade = cidadeRepository.findById(id);
        if (cidade.isPresent()) {
            cidadeRepository.deleteById(id);
            return Boolean.TRUE;
        } else {
            return Boolean.TRUE;
        }
    }

    public CidadeOutputDTO alter(Cidade cidade, Long id) {
        Optional<Cidade> c = cidadeRepository.findById(id);
        if (c.isPresent()) {
            Cidade c1 = c.get();
            c1.setNome(cidade.getNome());
            c1.setIbge(cidade.getIbge());
            c1.setEstado(cidade.getEstado());
            return new CidadeOutputDTO(cidadeRepository.save(c1));
        } else {
            return new CidadeOutputDTO(c.get());
        }
    }


}
